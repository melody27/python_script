<?php

ini_set('allow_url_fopen',true);
ini_set('allow_url_include',true);
error_reporting(E_ERROR | E_PARSE);


if (!function_exists('apache_request_headers')){

    echo "the apache_request_headers function is not define";

}


$arp = 'test';
$tt = "{${arp}}a";
echo "\n".$tt;









?>